from django.shortcuts import render, HttpResponse

# Create your views here.
def index (request):
    return HttpResponse("<h1 style='color:blue'>Selamat Datang di halaman index</h1>")